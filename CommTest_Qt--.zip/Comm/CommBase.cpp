﻿#include "CommBase.h"

// CommBase::CommBase()
// {
// }
CommBase::CommBase(QObject* pParent)
	: QObject(pParent)
{
}

