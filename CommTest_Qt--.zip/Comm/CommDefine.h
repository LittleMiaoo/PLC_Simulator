﻿#ifndef COMM_DEFINE_H
#define COMM_DEFINE_H

//20251101	wm	通信相关头文件

//通信类型
#include "CommBase.h"
#include "CommSocket.h"

//通信协议类型
#include "CommProtocolBase.h"
#include "CommProKeyencePCLink.h"
#include "CommProMitsubishiQBinary.h"

#endif //COMM_DEFINE_H
