-- Lua Script File 1
-- Write your Lua code here
MoveRelativeInt32("D100", "D102", "D104")
